package SwagLabs;

import SwagLabs.utility.BeforeAndAfter;
import SwagLabs.utility.CheckoutFun;
import SwagLabs.utility.LogInFun;
import org.testng.annotations.Test;

public class Checkout extends BeforeAndAfter {
    @Test
    public void checkoutComplete() throws Exception{
        LogInFun.LogInValidUser(driver,wait);
        CheckoutFun.CheckoutComplete(driver,wait);
    }
}
