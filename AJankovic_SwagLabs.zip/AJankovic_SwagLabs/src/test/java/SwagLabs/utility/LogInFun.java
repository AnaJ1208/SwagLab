package SwagLabs.utility;

import SwagLabs.pageObject.LogInPageObject;
import SwagLabs.pageObject.LogoutPageObject;
import SwagLabs.utility.jsonFilesParser.JSONManagement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;

public class LogInFun {
    public static void LogInValidUser (WebDriver driver, WebDriverWait wait) throws IOException {

        driver.findElement(LogInPageObject.usernameField).sendKeys(JSONManagement.readProperty("standardUser"));
        driver.findElement(LogInPageObject.passwordField).sendKeys(JSONManagement.readProperty("password"));
        driver.findElement(LogInPageObject.loginButton).click();
        driver.findElement(LogInPageObject.productText).isDisplayed();
    }

    public static void LogInInvalid (WebDriver driver, WebDriverWait wait) throws IOException{
        driver.findElement(LogInPageObject.usernameField).sendKeys(" ");
        driver.findElement(LogInPageObject.passwordField).sendKeys(JSONManagement.readProperty("password"));
        driver.findElement(LogInPageObject.loginButton).click();
        driver.findElement(LogInPageObject.errorMessage).isDisplayed();
    }

    public static void Logout (WebDriver driver, WebDriverWait wait) throws IOException{
        driver.findElement(LogInPageObject.usernameField).sendKeys(JSONManagement.readProperty("standardUser"));
        driver.findElement(LogInPageObject.passwordField).sendKeys(JSONManagement.readProperty("password"));
        driver.findElement(LogInPageObject.loginButton).click();
        driver.findElement(LogoutPageObject.mnuButton).click();
        driver.findElement(LogoutPageObject.logoutOption).click();
        driver.findElement(LogoutPageObject.imgLoginPage).isDisplayed();
    }
}
