package SwagLabs.utility;

import SwagLabs.pageObject.CheckoutPage;
import SwagLabs.utility.jsonFilesParser.JSONManagement;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;

public class CheckoutFun {
    public static void CheckoutComplete (WebDriver driver, WebDriverWait wait) throws IOException{
        //cart
        driver.findElement(CheckoutPage.productTitle).isDisplayed();
        driver.findElement(CheckoutPage.addToCartButton).click();
        driver.findElement(CheckoutPage.cartButton).click();
        driver.findElement(CheckoutPage.yourCartText).isDisplayed();
        driver.findElement(CheckoutPage.qtyText).isDisplayed();
        driver.findElement(CheckoutPage.descriptionText).isDisplayed();
        driver.findElement(CheckoutPage.quantity).isDisplayed();
        driver.findElement(CheckoutPage.productTitle1).isDisplayed();
        //assert dodati za naslov poroizvoda
        driver.findElement(CheckoutPage.descriptionText).isDisplayed();
        driver.findElement(CheckoutPage.productDescription).isDisplayed();
        driver.findElement(CheckoutPage.productPrice).isDisplayed();
        driver.findElement(CheckoutPage.removeButton).isDisplayed();
        driver.findElement(CheckoutPage.continueShoppingButton).isDisplayed();
        driver.findElement(CheckoutPage.checkoutBtn).click();

        //checkout info
        driver.findElement(CheckoutPage.checkoutYourInfoText).isDisplayed();
        driver.findElement(CheckoutPage.firstnameField).sendKeys(CheckoutPage.firstname);
        driver.findElement(CheckoutPage.lastnameField).sendKeys(CheckoutPage.lastname);
        driver.findElement(CheckoutPage.zipCodeField).sendKeys(CheckoutPage.zip);
        driver.findElement(CheckoutPage.cancelButton).isDisplayed();
        driver.findElement(CheckoutPage.continueButton).click();

        //checkout overview
        driver.findElement(CheckoutPage.checkoutOverview).isDisplayed();
        driver.findElement(CheckoutPage.qty).isDisplayed();
        driver.findElement(CheckoutPage.desc).isDisplayed();
        driver.findElement(CheckoutPage.title).isDisplayed();
        driver.findElement(CheckoutPage.qtyField1).isDisplayed();
        driver.findElement(CheckoutPage.prodDesc).isDisplayed();
        driver.findElement(CheckoutPage.prodPrice).isDisplayed();
        driver.findElement(CheckoutPage.paymentInfo).isDisplayed();
        driver.findElement(CheckoutPage.shippingInfo).isDisplayed();
        driver.findElement(CheckoutPage.totalPrice).isDisplayed();
        driver.findElement(CheckoutPage.cancelBTN).isDisplayed();
        driver.findElement(CheckoutPage.finishButton).click();

        //checkout complete
        driver.findElement(CheckoutPage.checkoutCompleteText).isDisplayed();
        driver.findElement(CheckoutPage.thanksMessage).isDisplayed();
        driver.findElement(CheckoutPage.messageText).isDisplayed();
        driver.findElement(CheckoutPage.imageCheckout).isDisplayed();
        driver.findElement(CheckoutPage.backHomeButton).isDisplayed();

        //check product name
        Assert.assertEquals(CheckoutPage.productTitle, CheckoutPage.productTitle1);





    }
}
