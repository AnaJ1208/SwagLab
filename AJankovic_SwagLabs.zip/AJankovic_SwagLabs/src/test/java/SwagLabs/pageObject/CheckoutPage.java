package SwagLabs.pageObject;

import org.openqa.selenium.By;

public class CheckoutPage {
    //cart
    public static By productTitle = By.xpath("//*[@id=\"item_4_title_link\"]/div");
    public static By addToCartButton = By.xpath("//button[@id='add-to-cart-sauce-labs-backpack']");
    public static By cartButton = By.xpath("//*[@id=\"shopping_cart_container\"]/a/span");
    public static By yourCartText = By.xpath("//span[contains(text(),'Your Cart')]");
    public static By qtyText = By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[1]");
    public static By quantity = By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[1]");
    public static By descriptionText = By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[2]");
    public static By productTitle1 = By.xpath("//*[@id=\"item_4_title_link\"]/div");
    public static By productDescription = By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[1]");
    public static By productPrice = By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[2]/div");
    public static By removeButton = By.xpath("//button[@id='remove-sauce-labs-backpack']");
    public static By continueShoppingButton = By.xpath("//button[@id='continue-shopping']");
    public static By checkoutBtn = By.xpath("//button[@id='checkout']");
    //checkout information
    public static By checkoutYourInfoText = By.xpath("//span[contains(text(),'Checkout: Your Information')]");
    public static By firstnameField = By.xpath("//input[@id='first-name']");
    public static By lastnameField = By.xpath("//input[@id='last-name']");
    public static By zipCodeField = By.xpath("//input[@id='postal-code']");
    public static By cancelButton = By.xpath("//button[@id='cancel']");
    public static By continueButton = By.xpath("//input[@id='continue']");

    public static String firstname = "Ana";
    public static String lastname = "Jankovic";
    public static String zip = "11000";
    //checkout overview
    public static By checkoutOverview = By.xpath("//*[@id=\"header_container\"]/div[2]/span");
    public static By qty = By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[1]");
    public static By desc = By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[2]");
    public static By title = By.xpath("//*[@id=\"item_4_title_link\"]/div");
    public static By qtyField1 = By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[3]/div[1]");
    public static By prodDesc = By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[3]/div[2]/div[1]");
    public static By prodPrice = By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[1]/div[3]/div[2]/div[2]/div");
    public static By paymentInfo = By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[1]");
    public static By shippingInfo = By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[3]");
    public static By totalPrice = By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[7]");
    public static By cancelBTN = By.xpath("//button[@id='cancel']");
    public static By finishButton = By.xpath("//button[@id='finish']");
    //checkout complete
    public static By checkoutCompleteText = By.xpath("//span[contains(text(),'Checkout: Complete!')]");
    public static By thanksMessage = By.xpath("//h2[contains(text(),'THANK YOU FOR YOUR ORDER')]");
    public static By messageText = By.xpath("//*[@id=\"checkout_complete_container\"]/div");
    public static By imageCheckout = By.xpath("//body/div[@id='root']/div[@id='page_wrapper']/div[@id='contents_wrapper']/div[@id='checkout_complete_container']/img[1]");
    public static By backHomeButton = By.xpath("//button[@id='back-to-products']");

}
