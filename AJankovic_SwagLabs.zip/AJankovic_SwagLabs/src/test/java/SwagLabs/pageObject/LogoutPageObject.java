package SwagLabs.pageObject;

import org.openqa.selenium.By;

public class LogoutPageObject {
    public static By mnuButton = By.xpath("//button[@id='react-burger-menu-btn']");
    public static By logoutOption = By.xpath("//a[@id='logout_sidebar_link']");
    public static By imgLoginPage = By.xpath("//body/div[@id='root']/div[1]/div[2]/div[1]/div[2]");
}
