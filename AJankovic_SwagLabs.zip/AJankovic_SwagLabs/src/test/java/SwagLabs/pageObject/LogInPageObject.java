package SwagLabs.pageObject;

import org.openqa.selenium.By;

public class LogInPageObject {

    public static By usernameField = By.id("user-name");
    public static By passwordField = By.id("password");
    public static By loginButton = By.id("login-button");
    public static By productText = By.xpath("//span[contains(text(),'Products')]");

    public static By errorMessage = By.xpath("//body/div[@id='root']/div[1]/div[2]/div[1]/div[1]/div[1]/form[1]/div[3]/h3[1]");
}

