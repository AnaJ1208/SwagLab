package SwagLabs;

import SwagLabs.utility.BeforeAndAfter;
import SwagLabs.utility.LogInFun;
import org.testng.annotations.Test;

public class Logout extends BeforeAndAfter {
    @Test
    public void logout() throws Exception {
        LogInFun.Logout(driver,wait);
    }
}
