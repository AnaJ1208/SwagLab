package SwagLabs;

import SwagLabs.utility.BeforeAndAfter;
import SwagLabs.utility.LogInFun;
import org.testng.annotations.Test;

public class Login_Invalid extends BeforeAndAfter {
    @Test
    public void invalidLogin() throws Exception {
        LogInFun.LogInInvalid(driver,wait);


    }
}
